package com.example.JpaData;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.JpaData.Repos.PatientRepo;
import com.example.JpaData.entity.Patient;

@Controller
public class HelloController {
	@Autowired
	PatientRepo repos;

	@RequestMapping({ "/Reg" })
	public String welcome() {
		return "Register";
	}

	@RequestMapping({ "/patReg" })
	public String regform(Model m, @RequestParam(value = "patname", defaultValue = "akhil") String name,
			@RequestParam(value = "age", defaultValue = "3") String age,
			@RequestParam(value = "weight", defaultValue = "65") String weight,
			@RequestParam(value = "id", defaultValue = "2") Long id,
			@RequestParam(value = "reason", defaultValue = "ff") String reason,
			@RequestParam(value = "address", defaultValue = "akhil") String address,
			@RequestParam(value = "password", defaultValue = "akhil") String password,
			@RequestParam(value = "contact", defaultValue = "234") String contact) {

		Patient p = new Patient();
		p.setName(name);
		p.setAge(age);
		p.setWeight(weight);
		p.setAddress(address);
		p.setReason(reason);
		p.setContact(contact);
		p.setId(id);
		p.setPassword(password);
		repos.save(p);
		// System.out.println("Registration success "+p);
		// m.addAttribute("Successful Registration");
		m.addAttribute("successpage", "Data inserted success");
		return "successpage";

	}

	@GetMapping("/read")
	public String readStudent(Model model) throws IOException {

		List<Patient> alldetails = (List) repos.findAll();
		alldetails.stream().forEach(System.out::println);
		model.addAttribute("patients", alldetails);
		return "read";
	}

	@RequestMapping("/update/{id}")
	public String updateEmployee(Model model, @PathVariable("id")Long id ) {
		Patient p = repos.getPatientById(id);
		model.addAttribute("patient", p);
		return "update";
	}
	@RequestMapping("/updatedetails")
	public String update(@ModelAttribute("patient") Patient p,Model m) {
		repos.save(p);
		m.addAttribute("successpage","Updated successfully");
		return "successpage";
	}

	
	@RequestMapping("/delete/{id}")
	public String deleteStudent(@PathVariable(name = "id") Long id) {
		Patient p = repos.getPatientById(id);
		repos.delete(p);
		return "delete";
	}

	@RequestMapping("/login")

	public String log() {

		return "LoginPage";

	}

	@RequestMapping("/patlogin")
	public String gnoj(@RequestParam("name") String name, Model m, @RequestParam("password") String password) {
		Patient p = repos.findByNameAndPassword(name, password);

		if (!(ObjectUtils.isEmpty(p))) {
			m.addAttribute("successpage", "Login Successful");
			return "successpage";
		}

		return "unsucess";
	}

}

