package com.example.JpaData.Repos;

import org.springframework.data.repository.CrudRepository;

import com.example.JpaData.entity.Patient;
import com.example.JpaData.entity.Student1;

public interface PatientRepo extends CrudRepository<Patient, String> {

	Patient getPatientById(Long id);
	Patient findByNameAndPassword(String name,String Password);
	

}
