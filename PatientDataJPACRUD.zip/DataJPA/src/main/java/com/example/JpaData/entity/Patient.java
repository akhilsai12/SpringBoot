package com.example.JpaData.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import net.bytebuddy.implementation.auxiliary.AuxiliaryType.SignatureRelevant;

@Entity
public class Patient {
@Id
private Long id;
private String name;
private String age;
private String weight;
private String reason;
private String address;
private String email;
@Column(length = 10)
private String contact;
@Column()
@Size(min=8, max=20,message = "in b/w 8 to 20")
private String password;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getWeight() {
	return weight;
}
public void setWeight(String weight) {
	this.weight = weight;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Patient(Long id, String name, String age, String weight, String reason, String address, String email,
		String contact, String password) {
	super();
	this.id = id;
	this.name = name;
	this.age = age;
	this.weight = weight;
	this.reason = reason;
	this.address = address;
	this.email = email;
	this.contact = contact;
	this.password = password;
}
public Patient() {
	super();
}
@Override
public String toString() {
	return "Patient [id=" + id + ", name=" + name + ", age=" + age + ", weight=" + weight + ", reason=" + reason
			+ ", address=" + address + ", email=" + email + ", contact=" + contact + ", password=" + password + "]";
}

}
