package com.example.JpaData;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import com.example.JpaData.Repos.PatientRepo;
import com.example.JpaData.entity.Student1;

@SpringBootTest
class DataJpaApplicationTests {
	@Autowired
	ApplicationContext context;
	/*@Test
	void contextLoads() {
	PatientRepo studentRepo = context.getBean(PatientRepo.class);
	Student1 student=new Student1();
	student.setId("7");
	student.setName("Afbkf");
	student.setMail("fhh@nbvfjklng");
	student.setCourse("ML");
	studentRepo.save(student);
	}
	
*/
	

}
